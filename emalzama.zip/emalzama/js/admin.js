// Malzama.Krd Admin Engine & State Management
document.addEventListener('DOMContentLoaded', () => {

  // Default Store Datasets
  const defaultBooks = [
    {
      id: 'b9-1',
      title: 'کوردی پۆلی کتێبی قوتابی',
      subtitle: 'کوردی پۆلی 9',
      price: 24000,
      grade: 9,
      subject: 'literature',
      img: 'assets/images/book_kurdish_9_student_1790446968708.png',
      desc: 'کتێبی سەرەکی خوێندنی کوردی بۆ پۆلی نۆیەمی بنەڕەتی بەپێی نوێترین بەرنامەی وەزارەتی پەروەردە.'
    },
    {
      id: 'b9-2',
      title: 'کوردی پۆلی کتێبی وەرزشی',
      subtitle: 'کوردی پۆلی 9',
      price: 18000,
      grade: 9,
      subject: 'all',
      img: 'assets/images/book_kurdish_9_tree_1790446985742.png',
      desc: 'ڕێنمایی و بەرنامەی چالاکییە وەرزشییەکان بۆ پەروەردەی جەستەیی پۆلی نۆیەم.'
    },
    {
      id: 'b9-3',
      title: 'کوردی بۆ کتێبی مامۆستا',
      subtitle: 'کوردی پۆلی 9',
      price: 20000,
      grade: 9,
      subject: 'literature',
      img: 'assets/images/book_kurdish_9_purple_1790447004624.png',
      desc: 'کتێبی ڕێنمایی مامۆستا بۆ وانەوتنەوە و ڕوونکردنەوەی ناورۆکی کتێبی کوردی پۆلی 9.'
    },
    {
      id: 'b9-4',
      title: 'زمان و ئەدەب بۆ پۆلی 9',
      subtitle: 'زمان و ئەدەب پۆلی 9',
      price: 22000,
      grade: 9,
      subject: 'literature',
      img: 'assets/images/book_kurdish_9_literature_1790447021955.png',
      desc: 'شیکاری دەقە ئەدەبییەکان و هۆنراوەکانی پۆلی نۆیەم بە مێژووی ئەدەبەوە.'
    },
    {
      id: 'b9-5',
      title: 'ڕێزمان پۆلی 9',
      subtitle: 'ڕێزمان پۆلی 9',
      price: 21000,
      grade: 9,
      subject: 'grammar',
      img: 'assets/images/book_kurdish_9_grammar_1790447037156.png',
      desc: 'یاساکانی ڕێزمانی کوردی و دارشتن و وشەسازی بۆ ئەزموونەکانی پۆلی نۆیەم.'
    },
    {
      id: 'b9-6',
      title: 'دەقی کوردی پۆلی 9',
      subtitle: 'دەقی کوردی پۆلی 9',
      price: 19000,
      grade: 9,
      subject: 'literature',
      img: 'assets/images/book_kurdish_9_student_1790446968708.png',
      desc: 'کۆمەڵە دەق و پەخشانی ئەدەبی هەڵبژێردراو بۆ بەرەوپێشبردنی زمانی کوردی.'
    },
    {
      id: 'b10-1',
      title: 'کوردی پۆلی 10 (کۆمەڵایەتی)',
      subtitle: 'پۆلی 10',
      price: 25000,
      grade: 10,
      subject: 'literature',
      img: 'assets/images/book_kurdish_9_tree_1790446985742.png',
      desc: 'کتێبی ڕێزمانی کوردی و ئەدەب بۆ پۆلی دەیەمی ئامادەیی.'
    },
    {
      id: 'b10-2',
      title: 'ڕێزمانی پێشکەوتووی پۆلی 10',
      subtitle: 'پۆلی 10',
      price: 23000,
      grade: 10,
      subject: 'grammar',
      img: 'assets/images/book_kurdish_9_grammar_1790447037156.png',
      desc: 'شیکردنەوەی قووڵی ڕێزمانی کوردی بۆ قوتابیانی پۆلی دەیەم.'
    },
    {
      id: 'b11-1',
      title: 'کوردی پۆلی 11 (زانستی و وێژەیی)',
      subtitle: 'پۆلی 11',
      price: 26000,
      grade: 11,
      subject: 'literature',
      img: 'assets/images/book_kurdish_9_purple_1790447004624.png',
      desc: 'پڕۆگرامی وانەی کوردی پۆلی یازدەیەم بە بابەتە ئەدەبی و زانستییەکانەوە.'
    },
    {
      id: 'b12-1',
      title: 'مەلزەمەی ئەدەب و ڕێزمانی پۆلی 12',
      subtitle: 'پۆلی 12 - ئەلند',
      price: 28000,
      grade: 12,
      subject: 'grammar',
      img: 'assets/images/book_kurdish_9_literature_1790447021955.png',
      desc: 'مەلزەمەی گشتگیر و کورتکراوەی پۆلی 12 بۆ ئەزموونە گشتییەکان (بەکالۆریۆس).'
    },
    {
      id: 'b12-2',
      title: 'کتێبی ڕێزمانی وزاری پۆلی 12',
      subtitle: 'پۆلی 12',
      price: 27000,
      grade: 12,
      subject: 'grammar',
      img: 'assets/images/book_kurdish_9_student_1790446968708.png',
      desc: 'پرسیارەکانی وەزاری خولەکانی پێشوو بە وەڵامی داڕێژراوەوە.'
    }
  ];

  const defaultUsedBooks = [
    {
      id: 'u1',
      title: 'کتێبی بیریاری پۆلی 12 (دەستی دوو)',
      grade: 'پۆلی 12',
      condition: 'زۆر باش (نوێ)',
      price: 12000,
      seller: 'ئاراس ئەحمەد',
      phone: '07501234567',
      img: 'assets/images/book_kurdish_9_purple_1790447004624.png',
      status: 'پەسەندکراو'
    },
    {
      id: 'u2',
      title: 'کیمیای پۆلی 11 زانستی',
      grade: 'پۆلی 11',
      condition: 'پاک و بێ خەت',
      price: 9000,
      seller: 'سارا عومەر',
      phone: '07709876543',
      img: 'assets/images/book_kurdish_9_grammar_1790447037156.png',
      status: 'پەسەندکراو'
    }
  ];

  const defaultOrders = [
    {
      id: 'MZ-8842',
      customer: 'کاروان عەلی',
      phone: '07501112233',
      city: 'هەولێر',
      address: 'شاری ٤ی گوڵان، بەرامبەر پارك',
      date: '2026-09-25',
      total: 49000,
      status: 'لە پرۆسەکردندا',
      step: 2,
      items: 'کوردی پۆلی کتێبی قوتابی x1, زمان و ئەدەب x1'
    },
    {
      id: 'MZ-7419',
      customer: 'دانەر حەسەن',
      phone: '07704445566',
      city: 'سلێمانی',
      address: 'سەرچنار، گەڕەکی شۆڕش',
      date: '2026-09-24',
      total: 28000,
      status: 'گەیەندرا',
      step: 4,
      items: 'مەلزەمەی ئەدەب و ڕێزمانی پۆلی 12 x1'
    }
  ];

  const defaultNotifications = [
    { id: 1, title: 'داواکاریەکەت وەرگیرا', desc: 'داواکاری #MZ-8842 لە پرۆسەی ئامادەکردندایە.', time: 'پێش ٢ کاتژمێر' },
    { id: 2, title: 'داشکاندنی تایبەت!', desc: 'کتێبەکانی پۆلی ١٢ تا %٢٠ داشکاندنیان بۆ کراوە.', time: 'دوێنێ' }
  ];

  // Helper State Loader & Saver
  function loadData(key, fallback) {
    try {
      const stored = localStorage.getItem(key);
      return stored ? JSON.parse(stored) : fallback;
    } catch (e) {
      return fallback;
    }
  }

  function saveData(key, data) {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      console.error('Error saving data:', e);
    }
  }

  // Admin Data Store
  const adminStore = {
    books: loadData('malzama_books_v1', defaultBooks),
    orders: loadData('malzama_orders_v1', defaultOrders),
    usedBooks: loadData('malzama_used_v1', defaultUsedBooks),
    notifications: loadData('malzama_notifs_v1', defaultNotifications),
    currentSection: 'dashboard',
    bookGradeFilter: 'all',
    orderStatusFilter: 'all',
    searchBookQuery: '',
    searchOrderQuery: ''
  };

  // Sync back defaults to localStorage if first time loading
  if (!localStorage.getItem('malzama_books_v1')) saveData('malzama_books_v1', adminStore.books);
  if (!localStorage.getItem('malzama_orders_v1')) saveData('malzama_orders_v1', adminStore.orders);
  if (!localStorage.getItem('malzama_used_v1')) saveData('malzama_used_v1', adminStore.usedBooks);
  if (!localStorage.getItem('malzama_notifs_v1')) saveData('malzama_notifs_v1', adminStore.notifications);

  // UI Elements
  const modalOverlay = document.getElementById('adminModalOverlay');
  const modalBody = document.getElementById('adminModalBody');
  const toastContainer = document.getElementById('adminToastContainer');

  function showToast(msg) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<i class="fa-solid fa-circle-check"></i> ${msg}`;
    toastContainer.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(-10px)';
      setTimeout(() => toast.remove(), 300);
    }, 2800);
  }

  // Render Functions
  function renderDashboard() {
    // KPI Updates
    const totalRev = adminStore.orders.reduce((sum, o) => sum + (o.total || 0), 0);
    document.getElementById('kpiTotalRevenue').textContent = `${totalRev.toLocaleString()} IQD`;
    document.getElementById('kpiTotalOrders').textContent = adminStore.orders.length;
    document.getElementById('kpiTotalBooks').textContent = adminStore.books.length;
    document.getElementById('kpiUsedBooks').textContent = adminStore.usedBooks.length;

    // Analytics Breakdown
    const processingOrders = adminStore.orders.filter(o => o.status === 'لە پرۆسەکردندا' || o.step === 2).length;
    const shippedOrders = adminStore.orders.filter(o => o.status === 'لە ڕێگایە' || o.step === 3).length;
    const deliveredOrders = adminStore.orders.filter(o => o.status === 'گەیەندرا' || o.step === 4).length;
    const totalO = adminStore.orders.length || 1;

    document.getElementById('dashAnalytics').innerHTML = `
      <div class="bar-item">
        <div class="bar-labels">
          <span>گەیەندراوەکان (${deliveredOrders})</span>
          <span>${Math.round((deliveredOrders / totalO) * 100)}%</span>
        </div>
        <div class="bar-track"><div class="bar-fill green" style="width:${(deliveredOrders / totalO) * 100}%;"></div></div>
      </div>
      <div class="bar-item">
        <div class="bar-labels">
          <span>لە پرۆسەکردندا (${processingOrders})</span>
          <span>${Math.round((processingOrders / totalO) * 100)}%</span>
        </div>
        <div class="bar-track"><div class="bar-fill gold" style="width:${(processingOrders / totalO) * 100}%;"></div></div>
      </div>
      <div class="bar-item">
        <div class="bar-labels">
          <span>لە ڕێگایە (${shippedOrders})</span>
          <span>${Math.round((shippedOrders / totalO) * 100)}%</span>
        </div>
        <div class="bar-track"><div class="bar-fill blue" style="width:${(shippedOrders / totalO) * 100}%;"></div></div>
      </div>
    `;

    // Recent Orders Table
    const recentOrdersTable = document.getElementById('dashRecentOrders');
    const recent = adminStore.orders.slice(0, 5);
    if (recent.length === 0) {
      recentOrdersTable.innerHTML = `<tr><td colspan="5" style="text-align:center; color:var(--text-muted);">هیچ داواکارییەک نییە</td></tr>`;
    } else {
      recentOrdersTable.innerHTML = recent.map(o => `
        <tr>
          <td><strong style="color:var(--primary);">${o.id}</strong></td>
          <td>${o.customer || 'نەنێردراو'}</td>
          <td>${o.total ? o.total.toLocaleString() : 0} IQD</td>
          <td><span class="status-pill ${getStatusPillClass(o.status)}">${o.status}</span></td>
          <td>
            <button class="btn-secondary" style="padding:4px 10px; font-size:0.78rem;" onclick="window.adminSwitchSection('orders')">بینیین</button>
          </td>
        </tr>
      `).join('');
    }
  }

  function renderBooks() {
    let filtered = adminStore.books;
    if (adminStore.bookGradeFilter !== 'all') {
      filtered = filtered.filter(b => b.grade === parseInt(adminStore.bookGradeFilter));
    }
    if (adminStore.searchBookQuery.trim() !== '') {
      const q = adminStore.searchBookQuery.toLowerCase();
      filtered = filtered.filter(b => b.title.toLowerCase().includes(q) || b.desc.toLowerCase().includes(q));
    }

    const tbody = document.getElementById('booksTableBody');
    if (filtered.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:30px; color:var(--text-muted);">هیچ کتێبێک بەم تایبەتمەندییە نەدۆزرایەوە</td></tr>`;
      return;
    }

    tbody.innerHTML = filtered.map(b => `
      <tr>
        <td><img src="${b.img}" alt="${b.title}" class="table-img"></td>
        <td>
          <div style="font-weight:800; color:var(--text-main);">${b.title}</div>
          <div style="font-size:0.78rem; color:var(--text-muted);">${b.subtitle || ''}</div>
        </td>
        <td><span class="status-pill shipped">پۆلی ${b.grade}</span></td>
        <td><span style="font-size:0.82rem; font-weight:700; color:var(--text-muted);">${getSubjectLabel(b.subject)}</span></td>
        <td style="font-weight:800; color:var(--primary);">${b.price.toLocaleString()} IQD</td>
        <td>
          <div class="action-btn-group">
            <button class="btn-icon-action edit" onclick="window.openEditBookModal('${b.id}')" title="دەستکاری"><i class="fa-solid fa-pen"></i></button>
            <button class="btn-icon-action delete" onclick="window.deleteBook('${b.id}')" title="سڕینەوە"><i class="fa-solid fa-trash"></i></button>
          </div>
        </td>
      </tr>
    `).join('');
  }

  function getSubjectLabel(sub) {
    if (sub === 'literature') return 'زمان و ئەدەب';
    if (sub === 'grammar') return 'ڕێزمان';
    return 'گشتی';
  }

  function renderOrders() {
    let filtered = adminStore.orders;
    if (adminStore.orderStatusFilter !== 'all') {
      filtered = filtered.filter(o => o.status === adminStore.orderStatusFilter);
    }
    if (adminStore.searchOrderQuery.trim() !== '') {
      const q = adminStore.searchOrderQuery.toLowerCase();
      filtered = filtered.filter(o => 
        o.id.toLowerCase().includes(q) || 
        (o.customer && o.customer.toLowerCase().includes(q)) || 
        (o.phone && o.phone.includes(q))
      );
    }

    const tbody = document.getElementById('ordersTableBody');
    if (filtered.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:30px; color:var(--text-muted);">هیچ داواکارییەک نەدۆزرایەوە</td></tr>`;
      return;
    }

    tbody.innerHTML = filtered.map(o => `
      <tr>
        <td><strong style="color:var(--primary);">${o.id}</strong></td>
        <td>
          <div style="font-weight:800;">${o.customer || 'خوێندکار'}</div>
          <div style="font-size:0.78rem; color:var(--text-muted);"><i class="fa-solid fa-phone" style="font-size:10px;"></i> ${o.phone || '0750XXXXXXX'}</div>
        </td>
        <td style="font-size:0.82rem;">${o.city || 'هەولێر'}<br><span style="color:var(--text-muted); font-size:0.78rem;">${o.address || ''}</span></td>
        <td style="font-weight:800; color:var(--primary);">${o.total ? o.total.toLocaleString() : 0} IQD</td>
        <td style="font-size:0.82rem; color:var(--text-muted);">${o.date || ''}</td>
        <td>
          <select class="status-select-dropdown" onchange="window.updateOrderStatus('${o.id}', this.value)" style="padding:4px 8px; border-radius:8px; border:1px solid var(--border-color); font-family:inherit; font-size:0.82rem; font-weight:700;">
            <option value="لە پرۆسەکردندا" ${o.status === 'لە پرۆسەکردندا' ? 'selected' : ''}>لە پرۆسەکردندا</option>
            <option value="لە ڕێگایە" ${o.status === 'لە ڕێگایە' ? 'selected' : ''}>لە ڕێگایە</option>
            <option value="گەیەندرا" ${o.status === 'گەیەندرا' ? 'selected' : ''}>گەیەندرا</option>
            <option value="ڕەتکراوە" ${o.status === 'ڕەتکراوە' ? 'selected' : ''}>ڕەتکراوە</option>
          </select>
        </td>
        <td>
          <div class="action-btn-group">
            <button class="btn-icon-action view" onclick="window.viewOrderDetail('${o.id}')" title="وردەکاری"><i class="fa-solid fa-eye"></i></button>
            <button class="btn-icon-action delete" onclick="window.deleteOrder('${o.id}')" title="سڕینەوە"><i class="fa-solid fa-trash"></i></button>
          </div>
        </td>
      </tr>
    `).join('');
  }

  function getStatusPillClass(status) {
    if (status === 'گەیەندرا') return 'delivered';
    if (status === 'لە ڕێگایە') return 'shipped';
    if (status === 'ڕەتکراوە') return 'cancelled';
    return 'processing';
  }

  function renderUsedBooks() {
    const grid = document.getElementById('usedBooksGridAdmin');
    if (adminStore.usedBooks.length === 0) {
      grid.innerHTML = `<div style="grid-column:1/-1; text-align:center; padding:40px; color:var(--text-muted);">هیچ کتێبێکی دەستی دوو نییە</div>`;
      return;
    }

    grid.innerHTML = adminStore.usedBooks.map(u => `
      <div class="admin-card" style="display:flex; gap:16px; align-items:center;">
        <img src="${u.img}" alt="${u.title}" style="width:70px; height:90px; object-fit:cover; border-radius:8px;">
        <div style="flex-grow:1;">
          <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:4px;">
            <span class="status-pill approved">${u.grade || 'پۆلی 12'}</span>
            <span style="font-weight:800; color:#059669;">${u.price ? u.price.toLocaleString() : 0} IQD</span>
          </div>
          <h4 style="font-size:0.95rem; font-weight:800; margin-bottom:2px;">${u.title}</h4>
          <p style="font-size:0.8rem; color:var(--text-muted); margin-bottom:8px;">خاوەن: ${u.seller || 'خوێندکار'} • ${u.phone || ''}</p>
          <div style="display:flex; gap:8px;">
            <a href="tel:${u.phone}" class="btn-secondary" style="padding:4px 10px; font-size:0.78rem;"><i class="fa-solid fa-phone"></i> پەیوەندی</a>
            <button class="btn-secondary" style="padding:4px 10px; font-size:0.78rem; color:#ef4444;" onclick="window.deleteUsedBook('${u.id}')"><i class="fa-solid fa-trash"></i> سڕینەوە</button>
          </div>
        </div>
      </div>
    `).join('');
  }

  function renderNotifications() {
    const list = document.getElementById('notifAdminList');
    if (adminStore.notifications.length === 0) {
      list.innerHTML = `<div style="text-align:center; padding:30px; color:var(--text-muted);">هیچ ئاگادارییەک نییە</div>`;
      return;
    }

    list.innerHTML = adminStore.notifications.map(n => `
      <div style="padding:14px; background:var(--secondary-bg); border-radius:12px; border-right:4px solid var(--primary); display:flex; justify-content:space-between; align-items:center;">
        <div>
          <div style="font-weight:800; font-size:0.95rem; margin-bottom:2px;">${n.title}</div>
          <div style="font-size:0.85rem; color:var(--text-muted);">${n.desc}</div>
          <div style="font-size:0.75rem; color:var(--text-light); margin-top:4px;">${n.time || 'ئێستا'}</div>
        </div>
        <button class="btn-icon-action delete" onclick="window.deleteNotification(${n.id})"><i class="fa-solid fa-trash"></i></button>
      </div>
    `).join('');
  }

  // Section Switching
  window.adminSwitchSection = function(sectionId) {
    adminStore.currentSection = sectionId;

    document.querySelectorAll('.sidebar-link').forEach(link => {
      if (link.getAttribute('data-section') === sectionId) {
        link.classList.add('active');
      } else {
        link.classList.remove('active');
      }
    });

    document.querySelectorAll('.admin-section').forEach(sec => {
      if (sec.id === `section-${sectionId}`) {
        sec.classList.add('active');
      } else {
        sec.classList.remove('active');
      }
    });

    // Title update
    const titles = {
      dashboard: 'داشبۆردی سەرەکی',
      books: 'بەڕێوەبردنی کتێبەکان',
      orders: 'بەڕێوەبردنی داواکارییەکان',
      used: 'کتێبی دەستی دوو',
      notifications: 'ئاگادارییەکان',
      settings: 'ڕێکخستنەکان'
    };
    document.getElementById('pageTitle').textContent = titles[sectionId] || 'بەڕێوەبەرایەتی';

    if (sectionId === 'dashboard') renderDashboard();
    if (sectionId === 'books') renderBooks();
    if (sectionId === 'orders') renderOrders();
    if (sectionId === 'used') renderUsedBooks();
    if (sectionId === 'notifications') renderNotifications();

    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Window Action Handlers
  window.openAddBookModal = function() {
    modalBody.innerHTML = `
      <div class="modal-header">
        <h3>زیادکردنی کتێبی نوێ</h3>
        <button class="modal-close-btn" onclick="window.closeAdminModal()"><i class="fa-solid fa-xmark"></i></button>
      </div>
      <form id="addBookForm">
        <div class="form-grid">
          <div class="form-group form-group-full">
            <label>ناوی کتێب</label>
            <input type="text" id="newTitle" placeholder="نموونە: بیرکاری پۆلی 9" required>
          </div>
          <div class="form-group">
            <label>پۆلی خوێندن</label>
            <select id="newGrade">
              <option value="9">پۆلی 9</option>
              <option value="10">پۆلی 10</option>
              <option value="11">پۆلی 11</option>
              <option value="12">پۆلی 12</option>
            </select>
          </div>
          <div class="form-group">
            <label>بابەت / پۆلێن</label>
            <select id="newSubject">
              <option value="literature">زمان و ئەدەب</option>
              <option value="grammar">ڕێزمان</option>
              <option value="all">گشتی</option>
            </select>
          </div>
          <div class="form-group">
            <label>نرخ (IQD)</label>
            <input type="number" id="newPrice" placeholder="25000" required>
          </div>
          <div class="form-group">
            <label>ژێرناونیشان / ژمارەی چاپ</label>
            <input type="text" id="newSubtitle" placeholder="چاپی نوێ" required>
          </div>
          <div class="form-group form-group-full">
            <label>وێنەی بەرگ (هەڵبژاردن یان بەستەر)</label>
            <select id="newImgPreset" style="margin-bottom:8px;">
              <option value="assets/images/book_kurdish_9_student_1790446968708.png">بەرگی قوتابی (شین)</option>
              <option value="assets/images/book_kurdish_9_tree_1790446985742.png">بەرگی دار (سەوز)</option>
              <option value="assets/images/book_kurdish_9_purple_1790447004624.png">بەرگی مامۆستا (مۆر)</option>
              <option value="assets/images/book_kurdish_9_literature_1790447021955.png">بەرگی زمان و ئەدەب</option>
              <option value="assets/images/book_kurdish_9_grammar_1790447037156.png">بەرگی ڕێزمان</option>
            </select>
          </div>
          <div class="form-group form-group-full">
            <label>شیکردنەوە و وەصف</label>
            <textarea id="newDesc" rows="3" placeholder="توضیحاتی کتێب بنووسە..." required></textarea>
          </div>
        </div>
        <button type="submit" class="btn-primary" style="width:100%; justify-content:center; margin-top:16px;">تۆمارکردن لە کتێبخانە</button>
      </form>
    `;
    modalOverlay.classList.add('active');

    document.getElementById('addBookForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const newBook = {
        id: `b${document.getElementById('newGrade').value}-${Date.now()}`,
        title: document.getElementById('newTitle').value,
        subtitle: document.getElementById('newSubtitle').value,
        price: parseInt(document.getElementById('newPrice').value),
        grade: parseInt(document.getElementById('newGrade').value),
        subject: document.getElementById('newSubject').value,
        img: document.getElementById('newImgPreset').value,
        desc: document.getElementById('newDesc').value
      };

      adminStore.books.unshift(newBook);
      saveData('malzama_books_v1', adminStore.books);
      window.closeAdminModal();
      showToast('کتێبی نوێ بە سەرکەوتوویی زێدە کرا');
      renderBooks();
    });
  };

  window.openEditBookModal = function(bookId) {
    const book = adminStore.books.find(b => b.id === bookId);
    if (!book) return;

    modalBody.innerHTML = `
      <div class="modal-header">
        <h3>دەستکاری کتێب: ${book.title}</h3>
        <button class="modal-close-btn" onclick="window.closeAdminModal()"><i class="fa-solid fa-xmark"></i></button>
      </div>
      <form id="editBookForm">
        <div class="form-grid">
          <div class="form-group form-group-full">
            <label>ناوی کتێب</label>
            <input type="text" id="editTitle" value="${book.title}" required>
          </div>
          <div class="form-group">
            <label>پۆلی خوێندن</label>
            <select id="editGrade">
              <option value="9" ${book.grade === 9 ? 'selected' : ''}>پۆلی 9</option>
              <option value="10" ${book.grade === 10 ? 'selected' : ''}>پۆلی 10</option>
              <option value="11" ${book.grade === 11 ? 'selected' : ''}>پۆلی 11</option>
              <option value="12" ${book.grade === 12 ? 'selected' : ''}>پۆلی 12</option>
            </select>
          </div>
          <div class="form-group">
            <label>بابەت / پۆلێن</label>
            <select id="editSubject">
              <option value="literature" ${book.subject === 'literature' ? 'selected' : ''}>زمان و ئەدەب</option>
              <option value="grammar" ${book.subject === 'grammar' ? 'selected' : ''}>ڕێزمان</option>
              <option value="all" ${book.subject === 'all' ? 'selected' : ''}>گشتی</option>
            </select>
          </div>
          <div class="form-group">
            <label>نرخ (IQD)</label>
            <input type="number" id="editPrice" value="${book.price}" required>
          </div>
          <div class="form-group">
            <label>ژێرناونیشان</label>
            <input type="text" id="editSubtitle" value="${book.subtitle || ''}" required>
          </div>
          <div class="form-group form-group-full">
            <label>شیکردنەوە و وەصف</label>
            <textarea id="editDesc" rows="3" required>${book.desc || ''}</textarea>
          </div>
        </div>
        <button type="submit" class="btn-primary" style="width:100%; justify-content:center; margin-top:16px;">پاشەکەوتکردنی گۆڕانکارییەکان</button>
      </form>
    `;
    modalOverlay.classList.add('active');

    document.getElementById('editBookForm').addEventListener('submit', (e) => {
      e.preventDefault();
      book.title = document.getElementById('editTitle').value;
      book.grade = parseInt(document.getElementById('editGrade').value);
      book.subject = document.getElementById('editSubject').value;
      book.price = parseInt(document.getElementById('editPrice').value);
      book.subtitle = document.getElementById('editSubtitle').value;
      book.desc = document.getElementById('editDesc').value;

      saveData('malzama_books_v1', adminStore.books);
      window.closeAdminModal();
      showToast('گۆڕانکارییەکان پاشەکەوت کران');
      renderBooks();
    });
  };

  window.deleteBook = function(bookId) {
    if (confirm('دڵنیایت لە سڕینەوەی ئەم کتێبە لە کتێبخانە؟')) {
      adminStore.books = adminStore.books.filter(b => b.id !== bookId);
      saveData('malzama_books_v1', adminStore.books);
      showToast('کتێبەکە سڕدرایەوە');
      renderBooks();
    }
  };

  window.updateOrderStatus = function(orderId, newStatus) {
    const order = adminStore.orders.find(o => o.id === orderId);
    if (!order) return;
    order.status = newStatus;
    if (newStatus === 'لە پرۆسەکردندا') order.step = 2;
    if (newStatus === 'لە ڕێگایە') order.step = 3;
    if (newStatus === 'گەیەندرا') order.step = 4;
    if (newStatus === 'ڕەتکراوە') order.step = 0;

    saveData('malzama_orders_v1', adminStore.orders);
    showToast(`بارودۆخی داواکاری #${orderId} گۆڕدرا بۆ: ${newStatus}`);
    renderOrders();
  };

  window.viewOrderDetail = function(orderId) {
    const o = adminStore.orders.find(item => item.id === orderId);
    if (!o) return;

    modalBody.innerHTML = `
      <div class="modal-header">
        <h3>وردەکاری داواکاری: ${o.id}</h3>
        <button class="modal-close-btn" onclick="window.closeAdminModal()"><i class="fa-solid fa-xmark"></i></button>
      </div>
      <div style="display:flex; flex-direction:column; gap:12px;">
        <div style="padding:12px; background:var(--secondary-bg); border-radius:12px;">
          <div style="font-weight:800; font-size:1rem; margin-bottom:4px;">${o.customer || 'خوێندکار'}</div>
          <div style="font-size:0.85rem; color:var(--text-muted);"><i class="fa-solid fa-phone"></i> ${o.phone || ''}</div>
          <div style="font-size:0.85rem; color:var(--text-muted);"><i class="fa-solid fa-location-dot"></i> ${o.city || ''} - ${o.address || ''}</div>
        </div>

        <div style="padding:12px; background:var(--secondary-bg); border-radius:12px;">
          <div style="font-weight:700; font-size:0.85rem; color:var(--text-muted); margin-bottom:6px;">کتێبە داواکراوەکان:</div>
          <div style="font-weight:800; font-size:0.95rem; color:var(--text-main);">${o.items || 'هیچ'}</div>
        </div>

        <div style="display:flex; justify-content:space-between; align-items:center; padding:12px; background:var(--primary-light); border-radius:12px; font-weight:800;">
          <span>کۆی پارەی داواکاری:</span>
          <span style="font-size:1.2rem; color:var(--primary);">${o.total ? o.total.toLocaleString() : 0} IQD</span>
        </div>
      </div>
    `;
    modalOverlay.classList.add('active');
  };

  window.deleteOrder = function(orderId) {
    if (confirm('دڵنیایت لە سڕینەوەی ئەم داواکارییە؟')) {
      adminStore.orders = adminStore.orders.filter(o => o.id !== orderId);
      saveData('malzama_orders_v1', adminStore.orders);
      showToast('داواکاریەکە سڕدرایەوە');
      renderOrders();
    }
  };

  window.deleteUsedBook = function(id) {
    if (confirm('دڵنیایت لە سڕینەوەی ئەم کتێبە دەستی دووە؟')) {
      adminStore.usedBooks = adminStore.usedBooks.filter(u => u.id !== id);
      saveData('malzama_used_v1', adminStore.usedBooks);
      showToast('کتێبی دەستی دوو سڕدرایەوە');
      renderUsedBooks();
    }
  };

  window.deleteNotification = function(id) {
    adminStore.notifications = adminStore.notifications.filter(n => n.id !== id);
    saveData('malzama_notifs_v1', adminStore.notifications);
    showToast('ئاگاداری سڕدرایەوە');
    renderNotifications();
  };

  window.closeAdminModal = function() {
    modalOverlay.classList.remove('active');
  };

  // Event Listeners Setup
  function setupEventListeners() {
    // Sidebar Section Switching
    document.querySelectorAll('.sidebar-link').forEach(link => {
      link.addEventListener('click', (e) => {
        const sec = link.getAttribute('data-section');
        if (sec) window.adminSwitchSection(sec);
      });
    });

    // Books Grade Filters
    document.querySelectorAll('.book-grade-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.book-grade-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        adminStore.bookGradeFilter = btn.getAttribute('data-grade');
        renderBooks();
      });
    });

    // Search Books
    const searchBookInput = document.getElementById('searchBookAdmin');
    if (searchBookInput) {
      searchBookInput.addEventListener('input', (e) => {
        adminStore.searchBookQuery = e.target.value;
        renderBooks();
      });
    }

    // Orders Status Filters
    document.querySelectorAll('.order-status-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.order-status-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        adminStore.orderStatusFilter = btn.getAttribute('data-status');
        renderOrders();
      });
    });

    // Search Orders
    const searchOrderInput = document.getElementById('searchOrderAdmin');
    if (searchOrderInput) {
      searchOrderInput.addEventListener('input', (e) => {
        adminStore.searchOrderQuery = e.target.value;
        renderOrders();
      });
    }

    // Broadcast Notification Form
    const notifForm = document.getElementById('broadcastNotifForm');
    if (notifForm) {
      notifForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const title = document.getElementById('notifTitle').value;
        const desc = document.getElementById('notifDesc').value;

        adminStore.notifications.unshift({
          id: Date.now(),
          title: title,
          desc: desc,
          time: 'ئێستا'
        });

        saveData('malzama_notifs_v1', adminStore.notifications);
        showToast('ئاگاداری گشتی بۆ سەرجەم بەکارهێنەران بڵاوکرایەوە');
        document.getElementById('notifTitle').value = '';
        document.getElementById('notifDesc').value = '';
        renderNotifications();
      });
    }

    // Reset Data Button
    const btnResetData = document.getElementById('btnResetData');
    if (btnResetData) {
      btnResetData.addEventListener('click', () => {
        if (confirm('دڵنیایت لە زانیاریەکانی سیستەم بۆ سەرەتا؟ (Reset All Data)')) {
          localStorage.removeItem('malzama_books_v1');
          localStorage.removeItem('malzama_orders_v1');
          localStorage.removeItem('malzama_used_v1');
          localStorage.removeItem('malzama_notifs_v1');
          location.reload();
        }
      });
    }

    // Toggle Sidebar Mobile
    const btnToggleSidebar = document.getElementById('btnToggleSidebar');
    const adminSidebar = document.getElementById('adminSidebar');
    if (btnToggleSidebar) {
      btnToggleSidebar.addEventListener('click', () => {
        adminSidebar.classList.toggle('open');
      });
    }

    // Toggle Dark Theme
    const btnToggleTheme = document.getElementById('btnToggleTheme');
    if (btnToggleTheme) {
      btnToggleTheme.addEventListener('click', () => {
        document.body.classList.toggle('dark-theme');
        showToast('دۆخی شاشە گۆڕدرا');
      });
    }

    // Modal Overlay Close
    modalOverlay.addEventListener('click', (e) => {
      if (e.target === modalOverlay) window.closeAdminModal();
    });
  }

  // Initialize Admin App
  function init() {
    setupEventListeners();
    renderDashboard();
  }

  init();
});
