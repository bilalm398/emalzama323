// Malzama.Krd Application Engine
document.addEventListener('DOMContentLoaded', () => {

  // Storage Persistence Helper
  function getStored(key, fallback) {
    try {
      const val = localStorage.getItem(key);
      return val ? JSON.parse(val) : fallback;
    } catch(e) { return fallback; }
  }
  function setStored(key, data) {
    try { localStorage.setItem(key, JSON.stringify(data)); } catch(e){}
  }

  // Global Application State
  const state = {
    currentGrade: 12, // Default Grade 12 (Matches reference image)
    selectedSubject: null, // null = show subject grid, string = show subject books
    searchQuery: '',
    cart: [
      { id: 'b12-1', title: 'مەڵزەمەی ئەدەب و ڕێزمانی پۆلی 12', price: 28000, qty: 1, img: getSubjectCoverSvg('kurdish', 12) },
      { id: 'b12-4', title: 'مەڵزەمەی بیرکاری پۆلی 12 - شیکاری زانستی', price: 25000, qty: 1, img: getSubjectCoverSvg('math', 12) }
    ],
    usedBooks: getStored('malzama_used_v1', [
      {
        id: 'u1',
        title: 'کتێبی بیریاری پۆلی 12 (دەستی دوو)',
        grade: 'پۆلی 12',
        condition: 'زۆر باش (نوێ)',
        price: 12000,
        seller: 'ئاراس ئەحمەد',
        phone: '07501234567',
        img: getSubjectCoverSvg('math', 12)
      },
      {
        id: 'u2',
        title: 'کیمیای پۆلی 11 زانستی',
        grade: 'پۆلی 11',
        condition: 'پاک و بێ خەت',
        price: 9000,
        seller: 'سارا عومەر',
        phone: '07709876543',
        img: getSubjectCoverSvg('chemistry', 11)
      }
    ]),
    orders: getStored('malzama_orders_v1', [
      {
        id: 'MZ-8842',
        customer: 'کاروان عەلی',
        phone: '07501112233',
        city: 'هەولێر',
        address: 'شاری ٤ی گوڵان',
        date: '2026-09-25',
        total: 53000,
        status: 'لە پرۆسەکردندا',
        step: 2,
        items: 'مەڵزەمەی ئەدەب و ڕێزمانی پۆلی 12 x1, مەڵزەمەی بیرکاری x1'
      }
    ]),
    notifications: getStored('malzama_notifs_v1', [
      { id: 1, title: 'داواکاریەکەت وەرگیرا', desc: 'داواکاری #MZ-8842 لە پرۆسەی ئامادەکردندایە.', time: 'پێش ٢ کژمێر' },
      { id: 2, title: 'داشکاندنی تایبەت!', desc: 'کتێبەکانی پۆلی ١٢ تا %٢٠ داشکاندنیان بۆ کراوە.', time: 'دوێنێ' }
    ]),
    currentView: 'sereki'
  };

  // Helper to generate custom SVG covers for each subject
  function getSubjectCoverSvg(subjectId, gradeNum) {
    const gStr = gradeNum === 12 ? '۱۲' : gradeNum === 11 ? '۱۱' : '۱۰';
    
    const svgs = {
      arabic: `
        <svg viewBox="0 0 100 130" xmlns="http://www.w3.org/2000/svg">
          <rect width="100" height="130" fill="#064e3b" rx="4"/>
          <path d="M 20 130 V 50 C 20 30 50 15 50 15 C 50 15 80 30 80 50 V 130 Z" fill="#047857" opacity="0.5"/>
          <circle cx="50" cy="45" r="14" fill="#f59e0b" opacity="0.8"/>
          <path d="M 38 78 C 50 68 50 68 62 78" stroke="#fbbf24" stroke-width="3" fill="none"/>
          <text x="50" y="98" fill="#ffffff" font-size="9.5" font-family="sans-serif" font-weight="bold" text-anchor="middle">اللغة العربية</text>
          <rect x="74" y="4" width="22" height="16" rx="3" fill="#0052cc"/>
          <text x="85" y="16" fill="#ffffff" font-size="10" font-family="sans-serif" font-weight="bold" text-anchor="middle">${gStr}</text>
        </svg>
      `,
      kurdish: `
        <svg viewBox="0 0 100 130" xmlns="http://www.w3.org/2000/svg">
          <rect width="100" height="130" fill="#d97706" rx="4"/>
          <circle cx="50" cy="48" r="22" fill="#fef3c7" opacity="0.3"/>
          <path d="M 42 38 C 42 30 58 30 58 38 C 58 46 52 50 52 56 L 48 56 C 48 50 42 46 42 38 Z" fill="#ffffff"/>
          <path d="M 36 68 C 36 56 64 56 64 68 V 73 H 36 Z" fill="#ffffff"/>
          <text x="50" y="96" fill="#ffffff" font-size="10" font-family="sans-serif" font-weight="bold" text-anchor="middle">ڕێزمانی کوردی</text>
          <rect x="74" y="4" width="22" height="16" rx="3" fill="#0052cc"/>
          <text x="85" y="16" fill="#ffffff" font-size="10" font-family="sans-serif" font-weight="bold" text-anchor="middle">${gStr}</text>
        </svg>
      `,
      english: `
        <svg viewBox="0 0 100 130" xmlns="http://www.w3.org/2000/svg">
          <rect width="100" height="130" fill="#0284c7" rx="4"/>
          <rect x="0" y="70" width="100" height="60" fill="#0369a1"/>
          <text x="50" y="32" fill="#ffffff" font-size="12" font-family="sans-serif" font-weight="bold" text-anchor="middle">Sunrise</text>
          <text x="50" y="48" fill="#facc15" font-size="14" font-family="sans-serif" font-weight="bold" text-anchor="middle">${gradeNum}</text>
          <path d="M 25 110 L 30 75 L 35 110 Z" fill="#bae6fd" opacity="0.7"/>
          <rect x="65" y="80" width="12" height="30" fill="#bae6fd" opacity="0.7"/>
          <polygon points="71,68 65,80 77,80" fill="#bae6fd" opacity="0.7"/>
          <rect x="74" y="4" width="22" height="16" rx="3" fill="#0052cc"/>
          <text x="85" y="16" fill="#ffffff" font-size="10" font-family="sans-serif" font-weight="bold" text-anchor="middle">${gStr}</text>
        </svg>
      `,
      math: `
        <svg viewBox="0 0 100 130" xmlns="http://www.w3.org/2000/svg">
          <rect width="100" height="130" fill="#1e3a8a" rx="4"/>
          <path d="M 10 110 Q 35 60 50 85 T 90 30" stroke="#ef4444" stroke-width="3" fill="none"/>
          <polygon points="90,30 80,35 85,45" fill="#ef4444"/>
          <text x="50" y="42" fill="#60a5fa" font-size="22" font-family="serif" font-weight="bold" text-anchor="middle">π</text>
          <text x="50" y="105" fill="#ffffff" font-size="11" font-family="sans-serif" font-weight="bold" text-anchor="middle">بیرکاری</text>
          <rect x="74" y="4" width="22" height="16" rx="3" fill="#0052cc"/>
          <text x="85" y="16" fill="#ffffff" font-size="10" font-family="sans-serif" font-weight="bold" text-anchor="middle">${gStr}</text>
        </svg>
      `,
      physics: `
        <svg viewBox="0 0 100 130" xmlns="http://www.w3.org/2000/svg">
          <rect width="100" height="130" fill="#0f172a" rx="4"/>
          <polygon points="50,25 20,70 80,70" fill="none" stroke="#38bdf8" stroke-width="2"/>
          <line x1="10" y1="50" x2="35" y2="48" stroke="#ffffff" stroke-width="2"/>
          <path d="M 65 55 L 90 40 M 65 55 L 90 50 M 65 55 L 90 60" stroke="#f43f5e" stroke-width="2"/>
          <circle cx="50" cy="52" r="5" fill="#38bdf8"/>
          <text x="50" y="102" fill="#ffffff" font-size="11" font-family="sans-serif" font-weight="bold" text-anchor="middle">فیزیا</text>
          <rect x="74" y="4" width="22" height="16" rx="3" fill="#0052cc"/>
          <text x="85" y="16" fill="#ffffff" font-size="10" font-family="sans-serif" font-weight="bold" text-anchor="middle">${gStr}</text>
        </svg>
      `,
      chemistry: `
        <svg viewBox="0 0 100 130" xmlns="http://www.w3.org/2000/svg">
          <rect width="100" height="130" fill="#581c87" rx="4"/>
          <path d="M 44 35 H 56 V 55 L 72 85 A 10 10 0 0 1 64 98 H 36 A 10 10 0 0 1 28 85 L 44 55 Z" fill="#9333ea" stroke="#c084fc" stroke-width="2"/>
          <circle cx="45" cy="78" r="4" fill="#38bdf8"/>
          <circle cx="55" cy="85" r="3" fill="#f43f5e"/>
          <circle cx="48" cy="65" r="3.5" fill="#facc15"/>
          <text x="50" y="115" fill="#ffffff" font-size="11" font-family="sans-serif" font-weight="bold" text-anchor="middle">کیمیا</text>
          <rect x="74" y="4" width="22" height="16" rx="3" fill="#ef4444"/>
          <text x="85" y="16" fill="#ffffff" font-size="10" font-family="sans-serif" font-weight="bold" text-anchor="middle">${gStr}</text>
        </svg>
      `,
      biology: `
        <svg viewBox="0 0 100 130" xmlns="http://www.w3.org/2000/svg">
          <rect width="100" height="130" fill="#15803d" rx="4"/>
          <path d="M 35 25 Q 65 45 35 65 T 35 105" stroke="#86efac" stroke-width="3" fill="none"/>
          <path d="M 65 25 Q 35 45 65 65 T 65 105" stroke="#4ade80" stroke-width="3" fill="none"/>
          <line x1="40" y1="35" x2="60" y2="35" stroke="#ffffff" stroke-width="2"/>
          <line x1="40" y1="75" x2="60" y2="75" stroke="#ffffff" stroke-width="2"/>
          <text x="50" y="118" fill="#ffffff" font-size="10" font-family="sans-serif" font-weight="bold" text-anchor="middle">زیندەزانی</text>
          <rect x="74" y="4" width="22" height="16" rx="3" fill="#ef4444"/>
          <text x="85" y="16" fill="#ffffff" font-size="10" font-family="sans-serif" font-weight="bold" text-anchor="middle">${gStr}</text>
        </svg>
      `,
      history: `
        <svg viewBox="0 0 100 130" xmlns="http://www.w3.org/2000/svg">
          <rect width="100" height="130" fill="#78350f" rx="4"/>
          <polygon points="50,30 20,48 80,48" fill="#fef3c7"/>
          <rect x="25" y="52" width="6" height="35" fill="#fde68a"/>
          <rect x="41" y="52" width="6" height="35" fill="#fde68a"/>
          <rect x="57" y="52" width="6" height="35" fill="#fde68a"/>
          <rect x="71" y="52" width="6" height="35" fill="#fde68a"/>
          <rect x="18" y="88" width="68" height="6" fill="#fef3c7"/>
          <text x="50" y="112" fill="#ffffff" font-size="11" font-family="sans-serif" font-weight="bold" text-anchor="middle">مێژوو</text>
          <rect x="74" y="4" width="22" height="16" rx="3" fill="#ef4444"/>
          <text x="85" y="16" fill="#ffffff" font-size="10" font-family="sans-serif" font-weight="bold" text-anchor="middle">${gStr}</text>
        </svg>
      `,
      geography: `
        <svg viewBox="0 0 100 130" xmlns="http://www.w3.org/2000/svg">
          <rect width="100" height="130" fill="#0369a1" rx="4"/>
          <circle cx="50" cy="50" r="26" fill="#38bdf8"/>
          <path d="M 35 45 C 40 35 55 35 60 42 C 55 55 40 55 35 45 Z" fill="#22c55e"/>
          <polygon points="15,95 40,65 65,95" fill="#94a3b8"/>
          <polygon points="40,95 65,58 90,95" fill="#cbd5e1"/>
          <text x="50" y="114" fill="#ffffff" font-size="10" font-family="sans-serif" font-weight="bold" text-anchor="middle">جۆگرافیا</text>
          <rect x="74" y="4" width="22" height="16" rx="3" fill="#0052cc"/>
          <text x="85" y="16" fill="#ffffff" font-size="10" font-family="sans-serif" font-weight="bold" text-anchor="middle">${gStr}</text>
        </svg>
      `,
      economics: `
        <svg viewBox="0 0 100 130" xmlns="http://www.w3.org/2000/svg">
          <rect width="100" height="130" fill="#ea580c" rx="4"/>
          <rect x="25" y="70" width="10" height="25" fill="#fde047"/>
          <rect x="40" y="55" width="10" height="40" fill="#fde047"/>
          <rect x="55" y="40" width="10" height="55" fill="#fde047"/>
          <rect x="70" y="25" width="10" height="70" fill="#fde047"/>
          <path d="M 20 70 L 40 52 L 60 40 L 80 20" stroke="#ffffff" stroke-width="3" stroke-linecap="round" fill="none"/>
          <text x="50" y="114" fill="#ffffff" font-size="11" font-family="sans-serif" font-weight="bold" text-anchor="middle">ئابووری</text>
          <rect x="74" y="4" width="22" height="16" rx="3" fill="#ea580c"/>
          <text x="85" y="16" fill="#ffffff" font-size="10" font-family="sans-serif" font-weight="bold" text-anchor="middle">${gStr}</text>
        </svg>
      `
    };

    const rawSvg = svgs[subjectId] || svgs.kurdish;
    return 'data:image/svg+xml;utf8,' + encodeURIComponent(rawSvg);
  }

  // Master Subject List (Matching screenshot order)
  const subjectsMaster = [
    { id: 'kurdish', name: 'کوردی', theme: 'theme-kurdish' },
    { id: 'arabic', name: 'عەرەبی', theme: 'theme-arabic' },
    { id: 'english', name: 'ئینگلیزی', theme: 'theme-english' },
    { id: 'math', name: 'بیرکاری', theme: 'theme-math' },
    { id: 'chemistry', name: 'کیمیا', theme: 'theme-chemistry' },
    { id: 'physics', name: 'فیزیا', theme: 'theme-physics' },
    { id: 'biology', name: 'زیندەزانی', theme: 'theme-biology' },
    { id: 'history', name: 'مێژوو', theme: 'theme-history' },
    { id: 'geography', name: 'جۆگرافیا', theme: 'theme-geography' },
    { id: 'economics', name: 'ئابووری', theme: 'theme-economics' }
  ];

  // Master Books Database
  const defaultBooksData = [
    // Grade 12 Books
    {
      id: 'b12-1',
      title: 'مەڵزەمەی ئەدەب و ڕێزمانی پۆلی 12',
      subtitle: 'پۆلی 12 - ئەلند',
      price: 28000,
      grade: 12,
      subjectId: 'kurdish',
      img: getSubjectCoverSvg('kurdish', 12),
      desc: 'مەڵزەمەی گشتگیر و کورتکراوەی پۆلی 12 بۆ ئەزموونە گشتییەکان (بەکالۆریۆس) بە شێوازێکی پڕۆفێشناڵ.'
    },
    {
      id: 'b12-2',
      title: 'کتێبی زمان و ئەدەبی کوردی 12',
      subtitle: 'وەزارەتی پەروەردە',
      price: 24000,
      grade: 12,
      subjectId: 'kurdish',
      img: getSubjectCoverSvg('kurdish', 12),
      desc: 'کتێبی ڕەسمی خوێندنی زمانی کوردی پۆلی ۱۲.'
    },
    {
      id: 'b12-3',
      title: 'اللغة العربية للصف الثاني عشر',
      subtitle: 'پۆلی 12 عەرەبی',
      price: 26000,
      grade: 12,
      subjectId: 'arabic',
      img: getSubjectCoverSvg('arabic', 12),
      desc: 'کتاب اللغة العربية الوزاري والشرح التفصيلي للقواعد والإعراب.'
    },
    {
      id: 'b12-4',
      title: 'مەڵزەمەی بیرکاری پۆلی 12 - شیکاری زانستی',
      subtitle: 'پۆلی 12 زانستی',
      price: 25000,
      grade: 12,
      subjectId: 'math',
      img: getSubjectCoverSvg('math', 12),
      desc: 'شیکارکردنی سەرجەم پرسیارە کانڤاس و وەزارییەکانی بیرکاری پۆلی ۱۲.'
    },
    {
      id: 'b12-5',
      title: 'Sunrise 12 Student Book & Activity',
      subtitle: 'English 12',
      price: 27000,
      grade: 12,
      subjectId: 'english',
      img: getSubjectCoverSvg('english', 12),
      desc: 'Complete Sunrise 12 official coursebook and activity exercises.'
    },
    {
      id: 'b12-6',
      title: 'مەڵزەمەی کیمیای پۆلی 12 زانستی',
      subtitle: 'پۆلی 12 کیمیا',
      price: 29000,
      grade: 12,
      subjectId: 'chemistry',
      img: getSubjectCoverSvg('chemistry', 12),
      desc: 'تەواوی بابەتەکانی کیمیا و هاوکێشەکان بە بەڵگەی شیکارکراوەوە.'
    },
    {
      id: 'b12-7',
      title: 'مەڵزەمەی فیزیای پۆلی 12 زانستی',
      subtitle: 'پۆلی 12 فیزیا',
      price: 29000,
      grade: 12,
      subjectId: 'physics',
      img: getSubjectCoverSvg('physics', 12),
      desc: 'یاساکانی فیزیا و پرسیارە وەزارییە هەڵبژێردراوەکانی ساڵانی پێشوو.'
    },
    {
      id: 'b12-8',
      title: 'مەڵزەمەی زیندەزانی پۆلی 12',
      subtitle: 'پۆلی 12 زیندەزانی',
      price: 26000,
      grade: 12,
      subjectId: 'biology',
      img: getSubjectCoverSvg('biology', 12),
      desc: 'شیکردنەوەی وردی بەشەکانی ژینگە و تەندروستی و جینات.'
    },
    {
      id: 'b12-9',
      title: 'مەڵزەمەی مێژووی پۆلی 12 وێژەیی',
      subtitle: 'پۆلی 12 وێژەیی',
      price: 23000,
      grade: 12,
      subjectId: 'history',
      img: getSubjectCoverSvg('history', 12),
      desc: 'مێژووی هاوچەرخی کوردستان و جیهان بە وێنە و ڕوونکردنەوەوە.'
    },
    {
      id: 'b12-10',
      title: 'مەڵزەمەی جۆگرافیای پۆلی 12',
      subtitle: 'پۆلی 12 وێژەیی',
      price: 24000,
      grade: 12,
      subjectId: 'geography',
      img: getSubjectCoverSvg('geography', 12),
      desc: 'جۆگرافیای سروشتی و مرۆیی بۆ تاقیکردنەوە گشتییەکان.'
    },
    {
      id: 'b12-11',
      title: 'مەڵزەمەی ئابووری پۆلی 12',
      subtitle: 'پۆلی 12 وێژەیی',
      price: 22000,
      grade: 12,
      subjectId: 'economics',
      img: getSubjectCoverSvg('economics', 12),
      desc: 'یاسا ئابوورییەکان و ژمێریاری بەرنامەی وەزارەتی پەروەردە.'
    },

    // Grade 11 Books
    {
      id: 'b11-1',
      title: 'کوردی پۆلی 11 (زانستی و وێژەیی)',
      subtitle: 'پۆلی 11',
      price: 24000,
      grade: 11,
      subjectId: 'kurdish',
      img: getSubjectCoverSvg('kurdish', 11),
      desc: 'پڕۆگرامی وانەی کوردی پۆلی یازدەیەم.'
    },
    {
      id: 'b11-2',
      title: 'بیرکاری پۆلی 11 زانستی',
      subtitle: 'پۆلی 11',
      price: 25000,
      grade: 11,
      subjectId: 'math',
      img: getSubjectCoverSvg('math', 11),
      desc: 'بیرکاری پێشکەوتووی پۆلی یازدەیەم.'
    },

    // Grade 10 Books
    {
      id: 'b10-1',
      title: 'کوردی پۆلی 10',
      subtitle: 'پۆلی 10',
      price: 22000,
      grade: 10,
      subjectId: 'kurdish',
      img: getSubjectCoverSvg('kurdish', 10),
      desc: 'کتێبی ڕێزمانی کوردی و ئەدەب بۆ پۆلی دەیەمی ئامادەیی.'
    }
  ];

  const booksData = getStored('malzama_books_v1', defaultBooksData);

  // UI Elements
  const subjectsGrid = document.getElementById('subjectsGrid');
  const subjectBooksWrapper = document.getElementById('subjectBooksWrapper');
  const booksGrid = document.getElementById('booksGrid');
  const sectionTitle = document.getElementById('sectionTitle');
  const subjectCountPill = document.getElementById('subjectCountPill');
  const selectedSubjectTitle = document.getElementById('selectedSubjectTitle');
  const btnBackToSubjects = document.getElementById('btnBackToSubjects');

  const cartBadge = document.getElementById('cartBadge');
  const cartNavBadge = document.getElementById('cartNavBadge');
  const searchInput = document.getElementById('searchInput');
  const searchClear = document.getElementById('searchClear');
  const toastContainer = document.getElementById('toastContainer');
  const modalOverlay = document.getElementById('modalOverlay');
  const modalBody = document.getElementById('modalBody');

  // Convert English numbers to Kurdish digits helper
  function toKurdishDigits(num) {
    const kurdishDigits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    return num.toString().replace(/\d/g, d => kurdishDigits[d]);
  }

  // Render Functions
  function renderMainView() {
    const kGrade = toKurdishDigits(state.currentGrade);

    // If searching, filter subjects or books
    if (state.searchQuery.trim() !== '') {
      const q = state.searchQuery.toLowerCase();
      const filteredSubjects = subjectsMaster.filter(s => s.name.toLowerCase().includes(q));
      
      sectionTitle.textContent = `ئەنجامەکانی گەڕان ("${state.searchQuery}")`;
      subjectCountPill.textContent = `${toKurdishDigits(filteredSubjects.length)} بابەت`;

      renderSubjectCards(filteredSubjects);
      subjectBooksWrapper.style.display = 'none';
      subjectsGrid.style.display = 'grid';
      return;
    }

    // Standard Subject Grid View
    if (state.selectedSubject === null) {
      sectionTitle.textContent = `بابەتەکانی پۆلی ${kGrade}`;
      subjectCountPill.textContent = `${toKurdishDigits(subjectsMaster.length)} بابەت`;

      renderSubjectCards(subjectsMaster);
      subjectBooksWrapper.style.display = 'none';
      subjectsGrid.style.display = 'grid';
    } else {
      // Selected specific subject view (show books for this subject)
      const subj = subjectsMaster.find(s => s.id === state.selectedSubject);
      const subjName = subj ? subj.name : 'کتێبەکان';
      
      sectionTitle.textContent = `کتێبەکان و مەڵزەمەکانی ${subjName}`;
      subjectCountPill.textContent = `پۆلی ${kGrade}`;
      selectedSubjectTitle.textContent = `مەڵزەمەکانی ${subjName}`;

      renderBooksForSubject(state.selectedSubject, state.currentGrade);
      subjectsGrid.style.display = 'none';
      subjectBooksWrapper.style.display = 'block';
    }
  }

  function renderSubjectCards(list) {
    if (list.length === 0) {
      subjectsGrid.innerHTML = `
        <div class="empty-state" style="grid-column: 1 / -1;">
          <div class="empty-icon"><i class="fa-solid fa-book-open"></i></div>
          <div class="empty-title">هیچ بابەتێک نەدۆزرایەوە</div>
          <div class="empty-desc">تکایە وشەی تر تاقی بکەرەوە.</div>
        </div>
      `;
      return;
    }

    subjectsGrid.innerHTML = list.map(subj => {
      const coverSrc = getSubjectCoverSvg(subj.id, state.currentGrade);
      return `
        <div class="subject-card ${subj.theme}" data-subject="${subj.id}">
          <div class="subject-card-action">
            <i class="fa-solid fa-chevron-left"></i>
          </div>
          <div class="subject-card-name">${subj.name}</div>
          <div class="subject-card-cover-wrapper">
            <img src="${coverSrc}" alt="${subj.name}" class="subject-card-cover-img">
          </div>
        </div>
      `;
    }).join('');

    // Attach click events to subject cards
    document.querySelectorAll('.subject-card').forEach(card => {
      card.addEventListener('click', () => {
        const subjId = card.getAttribute('data-subject');
        state.selectedSubject = subjId;
        renderMainView();
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    });
  }

  function renderBooksForSubject(subjId, grade) {
    let filtered = booksData.filter(b => b.grade === grade);

    if (subjId) {
      filtered = filtered.filter(b => b.subjectId === subjId || b.subject === subjId);
    }

    if (filtered.length === 0) {
      booksGrid.innerHTML = `
        <div class="empty-state" style="grid-column: 1 / -1;">
          <div class="empty-icon"><i class="fa-solid fa-book-open"></i></div>
          <div class="empty-title">مەڵزەمە لەم بەشەدا نییە</div>
          <div class="empty-desc">بەم زووانە مەڵزەمەی نوێ زیاد دەکرێت.</div>
        </div>
      `;
      return;
    }

    booksGrid.innerHTML = filtered.map(book => `
      <div class="book-card" data-id="${book.id}">
        <div class="book-cover-wrapper">
          <img src="${book.img}" alt="${book.title}" class="book-cover-img">
          <span class="book-badge">پۆلی ${toKurdishDigits(book.grade)}</span>
        </div>
        <div class="book-info">
          <div>
            <div class="book-title">${book.title}</div>
            <div class="book-subtitle">${book.subtitle}</div>
          </div>
          <div>
            <div class="book-price">${book.price.toLocaleString()} IQD</div>
            <button class="add-cart-btn" data-id="${book.id}">
              <i class="fa-solid fa-cart-shopping" style="margin-left:6px;"></i> کڕین
            </button>
          </div>
        </div>
      </div>
    `).join('');

    // Attach book click handlers
    document.querySelectorAll('.book-card').forEach(card => {
      card.addEventListener('click', (e) => {
        if (e.target.closest('.add-cart-btn')) return;
        const id = card.getAttribute('data-id');
        showBookDetails(id);
      });
    });

    document.querySelectorAll('.add-cart-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.getAttribute('data-id');
        addToCart(id);
      });
    });
  }

  function updateCartBadge() {
    const totalQty = state.cart.reduce((sum, item) => sum + item.qty, 0);
    cartBadge.textContent = totalQty;
    cartNavBadge.textContent = totalQty;
    if (totalQty === 0) {
      cartBadge.style.display = 'none';
      cartNavBadge.style.display = 'none';
    } else {
      cartBadge.style.display = 'flex';
      cartNavBadge.style.display = 'flex';
    }
  }

  function addToCart(bookId) {
    const book = booksData.find(b => b.id === bookId);
    if (!book) return;

    const existing = state.cart.find(item => item.id === bookId);
    if (existing) {
      existing.qty += 1;
    } else {
      state.cart.push({
        id: book.id,
        title: book.title,
        price: book.price,
        qty: 1,
        img: book.img
      });
    }

    updateCartBadge();
    showToast(`"${book.title}" زێدە کرایە سەبەتەکەت`);
    if (state.currentView === 'kart') renderCartView();
  }

  function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `<i class="fa-solid fa-circle-check"></i> ${message}`;
    toastContainer.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(-10px)';
      setTimeout(() => toast.remove(), 300);
    }, 2800);
  }

  // Views Switching Logic
  function switchView(viewName) {
    state.currentView = viewName;

    document.querySelectorAll('.nav-item').forEach(item => {
      if (item.getAttribute('data-view') === viewName) {
        item.classList.add('active');
      } else {
        item.classList.remove('active');
      }
    });

    document.querySelectorAll('.page-view').forEach(view => {
      if (view.id === `view-${viewName}`) {
        view.classList.add('active');
      } else {
        view.classList.remove('active');
      }
    });

    if (viewName === 'kart') renderCartView();
    if (viewName === 'dasti2') renderUsedBooksView();
    if (viewName === 'orders') renderOrdersView();
    if (viewName === 'profile') renderProfileView();

    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // Render Views Content
  function renderCartView() {
    const cartContainer = document.getElementById('cartContent');
    if (state.cart.length === 0) {
      cartContainer.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon"><i class="fa-solid fa-cart-flatbed"></i></div>
          <div class="empty-title">سەبەتەکەت بەتاڵە</div>
          <div class="empty-desc">هیچ کتێبێکت زیاده نەکردووە بۆ کڕین.</div>
          <button class="checkout-btn" style="max-width:200px; margin:20px auto 0;" id="btnGoHome">دەستپێکردنی کڕین</button>
        </div>
      `;
      document.getElementById('btnGoHome')?.addEventListener('click', () => switchView('sereki'));
      return;
    }

    const subtotal = state.cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
    const delivery = 3000;
    const total = subtotal + delivery;

    cartContainer.innerHTML = `
      <div class="cart-items-list">
        ${state.cart.map(item => `
          <div class="cart-item-card">
            <img src="${item.img}" alt="${item.title}" class="cart-item-img">
            <div class="cart-item-info">
              <div class="cart-item-title">${item.title}</div>
              <div class="cart-item-price">${(item.price * item.qty).toLocaleString()} IQD</div>
            </div>
            <div class="qty-controls">
              <button class="qty-btn" onclick="window.changeCartQty('${item.id}', 1)">+</button>
              <span style="font-size:0.9rem; font-weight:700;">${item.qty}</span>
              <button class="qty-btn" onclick="window.changeCartQty('${item.id}', -1)">-</button>
            </div>
          </div>
        `).join('')}
      </div>

      <div class="cart-summary">
        <div class="summary-row">
          <span>تێکڕای بەا:</span>
          <span>${subtotal.toLocaleString()} IQD</span>
        </div>
        <div class="summary-row">
          <span>کرێی گەیاندن:</span>
          <span>${delivery.toLocaleString()} IQD</span>
        </div>
        <div class="summary-row total">
          <span>کۆی گشتی:</span>
          <span style="color:var(--primary);">${total.toLocaleString()} IQD</span>
        </div>
        <button class="checkout-btn" id="btnCheckout">بەردەوامبوون بۆ پارەدان</button>
      </div>
    `;

    document.getElementById('btnCheckout').addEventListener('click', openCheckoutModal);
  }

  window.changeCartQty = function(id, delta) {
    const item = state.cart.find(i => i.id === id);
    if (!item) return;
    item.qty += delta;
    if (item.qty <= 0) {
      state.cart = state.cart.filter(i => i.id !== id);
    }
    updateCartBadge();
    renderCartView();
  };

  function renderUsedBooksView() {
    const container = document.getElementById('usedBooksContent');
    container.innerHTML = `
      <div class="used-hero">
        <div>
          <h3 style="font-size:1.2rem; font-weight:800; margin-bottom:4px;">بازاڕی کتێبی دەستی دوو</h3>
          <p style="font-size:0.85rem; opacity:0.9;">کتێبە کۆنەکانت بەبێ بەرامبەر بفرۆشە یان بپشکنە!</p>
        </div>
        <button class="btn-add-used" id="btnAddUsedBook">+ زیاده‌کردنی کتێب</button>
      </div>

      <div class="used-grid">
        ${state.usedBooks.map(item => `
          <div class="used-card">
            <img src="${item.img}" class="used-img" alt="${item.title}">
            <div class="used-details">
              <div>
                <span class="used-tag">${item.condition}</span>
                <h4 style="font-size:0.95rem; font-weight:800; margin:6px 0 2px;">${item.title}</h4>
                <p style="font-size:0.8rem; color:var(--text-muted);">${item.grade} • خاوەن: ${item.seller}</p>
              </div>
              <div style="display:flex; align-items:center; justify-content:space-between; margin-top:8px;">
                <span style="font-weight:800; color:#059669; font-size:0.9rem;">${item.price.toLocaleString()} IQD</span>
                <a href="tel:${item.phone}" class="used-contact-btn"><i class="fa-solid fa-phone"></i> پەیوەندی</a>
              </div>
            </div>
          </div>
        `).join('')}
      </div>
    `;

    document.getElementById('btnAddUsedBook').addEventListener('click', openAddUsedModal);
  }

  function renderOrdersView() {
    const container = document.getElementById('ordersContent');
    if (state.orders.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon"><i class="fa-solid fa-box-open"></i></div>
          <div class="empty-title">هیچ داواکاریەکت نییە</div>
          <div class="empty-desc">کاتێک داواکاری بکەیت لەم بەشەدا دەردەکەوێت.</div>
        </div>
      `;
      return;
    }

    container.innerHTML = state.orders.map(order => `
      <div class="order-card">
        <div class="order-header">
          <span>کۆدی داواکاری: ${order.id}</span>
          <span class="status-badge ${order.step === 4 ? 'delivered' : 'processing'}">${order.status}</span>
        </div>
        <div style="font-size:0.82rem; color:var(--text-muted); margin-bottom:8px;">
          ڕێککەوت: ${order.date} • کۆی گشتی: ${order.total.toLocaleString()} IQD
        </div>
        <div style="font-size:0.85rem; font-weight:600; background:var(--secondary-bg); padding:8px 12px; border-radius:8px; margin-bottom:12px;">
          ${order.items}
        </div>
        
        <div class="order-tracker">
          <div class="tracker-step ${order.step >= 1 ? 'completed' : ''}">
            <div class="tracker-dot"><i class="fa-solid fa-check"></i></div>
            <span>وەرگیرا</span>
          </div>
          <div class="tracker-step ${order.step >= 2 ? 'completed' : ''}">
            <div class="tracker-dot"><i class="fa-solid fa-gear"></i></div>
            <span>پرۆسەکردن</span>
          </div>
          <div class="tracker-step ${order.step >= 3 ? 'completed' : ''}">
            <div class="tracker-dot"><i class="fa-solid fa-truck"></i></div>
            <span>لە ڕێگایە</span>
          </div>
          <div class="tracker-step ${order.step >= 4 ? 'completed' : ''}">
            <div class="tracker-dot"><i class="fa-solid fa-house"></i></div>
            <span>گەیەندرا</span>
          </div>
        </div>
      </div>
    `).join('');
  }

  function renderProfileView() {
    const container = document.getElementById('profileContent');
    container.innerHTML = `
      <div class="profile-card">
        <div class="avatar-wrapper">
          <img src="https://ui-avatars.com/api/?name=Kurdish+Student&background=0052cc&color=fff&size=128" alt="Profile" class="avatar-img">
        </div>
        <h3 style="font-size:1.2rem; font-weight:800;">خوێندکاری پۆلی 12</h3>
        <p style="font-size:0.85rem; color:var(--text-muted);">0750 123 4567 • هەولێر، کوردستان</p>
      </div>

      <div class="profile-menu">
        <a href="admin.html" class="menu-item" style="text-decoration:none;">
          <div class="menu-item-left">
            <i class="fa-solid fa-user-gear" style="color:var(--primary);"></i>
            <span style="font-weight:700;">داشبۆردی بەڕێوەبەرایەتی (Admin Panel)</span>
          </div>
          <i class="fa-solid fa-chevron-left" style="font-size:12px; color:var(--text-muted);"></i>
        </a>
        <div class="menu-item" id="btnToggleTheme">
          <div class="menu-item-left">
            <i class="fa-solid fa-moon"></i>
            <span>دۆخی تاریک (Dark Mode)</span>
          </div>
          <i class="fa-solid fa-chevron-left" style="font-size:12px; color:var(--text-muted);"></i>
        </div>
        <div class="menu-item" onclick="alert('پەیوەندی بە پشتگیری: 0750 000 0000')">
          <div class="menu-item-left">
            <i class="fa-solid fa-headset"></i>
            <span>پشتیوانی و پەیوەندی</span>
          </div>
          <i class="fa-solid fa-chevron-left" style="font-size:12px; color:var(--text-muted);"></i>
        </div>
        <div class="menu-item" onclick="alert('Malzama.Krd v3.0.0 - هەموو مافەکانی پارێزراوە 2026')">
          <div class="menu-item-left">
            <i class="fa-solid fa-circle-info"></i>
            <span>دەربارەی مەلزەمە کورد</span>
          </div>
          <i class="fa-solid fa-chevron-left" style="font-size:12px; color:var(--text-muted);"></i>
        </div>
      </div>
    `;

    document.getElementById('btnToggleTheme').addEventListener('click', () => {
      document.body.classList.toggle('dark-theme');
      showToast('دۆخی ڕووناکی / تاریکی گۆڕدرا');
    });
  }

  // Modals Implementation
  function showBookDetails(bookId) {
    const book = booksData.find(b => b.id === bookId);
    if (!book) return;

    modalBody.innerHTML = `
      <button class="modal-close" onclick="window.closeModal()"><i class="fa-solid fa-xmark"></i></button>
      <div style="text-align:center; margin-bottom:16px;">
        <img src="${book.img}" style="width:140px; height:180px; object-fit:cover; border-radius:12px; box-shadow:0 8px 20px rgba(0,0,0,0.15);" alt="${book.title}">
      </div>
      <h3 style="font-size:1.25rem; font-weight:800; text-align:center; margin-bottom:4px;">${book.title}</h3>
      <p style="text-align:center; font-size:0.85rem; color:var(--text-muted); margin-bottom:16px;">${book.subtitle} • بڵاوکراوەی فەرمی</p>
      
      <p style="font-size:0.9rem; line-height:1.6; margin-bottom:20px; color:var(--text-main);">${book.desc}</p>
      
      <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:20px; background:var(--secondary-bg); padding:12px 16px; border-radius:12px;">
        <span style="font-size:0.9rem; font-weight:700;">نرخ:</span>
        <span style="font-size:1.2rem; font-weight:800; color:var(--primary);">${book.price.toLocaleString()} IQD</span>
      </div>

      <button class="checkout-btn" id="modalAddToCartBtn">
        <i class="fa-solid fa-cart-plus" style="margin-left:8px;"></i> زێدەکردن بۆ سەبەتە
      </button>
    `;

    modalOverlay.classList.add('active');
    document.getElementById('modalAddToCartBtn').addEventListener('click', () => {
      addToCart(book.id);
      window.closeModal();
    });
  }

  function openCheckoutModal() {
    const subtotal = state.cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
    const total = subtotal + 3000;

    modalBody.innerHTML = `
      <button class="modal-close" onclick="window.closeModal()"><i class="fa-solid fa-xmark"></i></button>
      <h3 style="font-size:1.2rem; font-weight:800; margin-bottom:16px; text-align:center;">تۆمارکردنی داواکاری</h3>
      
      <form id="checkoutForm">
        <div class="form-group">
          <label>ناوی تەواو</label>
          <input type="text" id="custName" placeholder="ناوی سیانیت بنووسە" required>
        </div>
        <div class="form-group">
          <label>ژمارەی مۆبایل</label>
          <input type="tel" id="custPhone" placeholder="0750 XXX XX XX" required>
        </div>
        <div class="form-group">
          <label>شار / ناوچە</label>
          <select id="custCity">
            <option>هەولێر</option>
            <option>سلێمانی</option>
            <option>دهۆک</option>
            <option>هەڵەبجە</option>
            <option>کەرکووک</option>
          </select>
        </div>
        <div class="form-group">
          <label>ناونیشانی ورد</label>
          <input type="text" id="custAddress" placeholder="گەڕەک / کۆڵان / بەرامبەر..." required>
        </div>

        <div style="margin:16px 0; padding:12px; background:var(--secondary-bg); border-radius:12px; font-weight:800; display:flex; justify-content:space-between;">
          <span>کۆی پارەدانی کۆتایی:</span>
          <span style="color:var(--primary);">${total.toLocaleString()} IQD</span>
        </div>

        <button type="submit" class="checkout-btn">ناردنی داواکاری</button>
      </form>
    `;

    modalOverlay.classList.add('active');

    document.getElementById('checkoutForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const custName = document.getElementById('custName').value;
      const custPhone = document.getElementById('custPhone').value;
      const custCity = document.getElementById('custCity').value;
      const custAddress = document.getElementById('custAddress').value;

      const newOrder = {
        id: `MZ-${Math.floor(1000 + Math.random() * 9000)}`,
        customer: custName,
        phone: custPhone,
        city: custCity,
        address: custAddress,
        date: new Date().toISOString().split('T')[0],
        total: total,
        status: 'لە پرۆسەکردندا',
        step: 1,
        items: state.cart.map(i => `${i.title} x${i.qty}`).join(', ')
      };

      state.orders.unshift(newOrder);
      setStored('malzama_orders_v1', state.orders);
      state.cart = [];
      updateCartBadge();
      window.closeModal();
      showToast('داواکاریەکەت بە سەرکەوتوویی تۆمارکرا!');
      switchView('orders');
    });
  }

  function openAddUsedModal() {
    modalBody.innerHTML = `
      <button class="modal-close" onclick="window.closeModal()"><i class="fa-solid fa-xmark"></i></button>
      <h3 style="font-size:1.2rem; font-weight:800; margin-bottom:16px; text-align:center;">زیادکردنی کتێبی دەستی دوو</h3>
      
      <form id="usedBookForm">
        <div class="form-group">
          <label>ناوی کتێب</label>
          <input type="text" id="ubTitle" placeholder="نموونە: بیریاری پۆلی 12" required>
        </div>
        <div class="form-group">
          <label>پۆل</label>
          <select id="ubGrade">
            <option>پۆلی 9</option>
            <option>پۆلی 10</option>
            <option>پۆلی 11</option>
            <option>پۆلی 12</option>
          </select>
        </div>
        <div class="form-group">
          <label>دۆخی کتێب</label>
          <input type="text" id="ubCondition" placeholder="نموونە: پاك و بێ خەت" required>
        </div>
        <div class="form-group">
          <label>نرخ (IQD)</label>
          <input type="number" id="ubPrice" placeholder="10000" required>
        </div>
        <div class="form-group">
          <label>ژمارەی پەیوەندی</label>
          <input type="tel" id="ubPhone" placeholder="0750 XXX XX XX" required>
        </div>

        <button type="submit" class="checkout-btn" style="background:linear-gradient(135deg, #059669 0%, #10b981 100%);">تۆمارکردن لە بازاڕ</button>
      </form>
    `;

    modalOverlay.classList.add('active');

    document.getElementById('usedBookForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const newUsedItem = {
        id: `u${Date.now()}`,
        title: document.getElementById('ubTitle').value,
        grade: document.getElementById('ubGrade').value,
        condition: document.getElementById('ubCondition').value,
        price: parseInt(document.getElementById('ubPrice').value),
        seller: 'خوێندکار',
        phone: document.getElementById('ubPhone').value,
        img: getSubjectCoverSvg('kurdish', 12)
      };

      state.usedBooks.unshift(newUsedItem);
      setStored('malzama_used_v1', state.usedBooks);

      window.closeModal();
      showToast('کتێبەکەت ڕەوانەی بازاڕی دەستی دوو کرا');
      renderUsedBooksView();
    });
  }

  function showNotificationsModal() {
    modalBody.innerHTML = `
      <button class="modal-close" onclick="window.closeModal()"><i class="fa-solid fa-xmark"></i></button>
      <h3 style="font-size:1.2rem; font-weight:800; margin-bottom:16px; text-align:center;">ئاگادارییەکان</h3>
      
      <div style="display:flex; flex-direction:column; gap:10px;">
        ${state.notifications.map(n => `
          <div style="padding:12px; background:var(--secondary-bg); border-radius:12px; border-right:4px solid var(--primary);">
            <div style="font-weight:700; font-size:0.92rem; margin-bottom:2px;">${n.title}</div>
            <div style="font-size:0.82rem; color:var(--text-muted); margin-bottom:4px;">${n.desc}</div>
            <div style="font-size:0.75rem; color:var(--text-light);">${n.time}</div>
          </div>
        `).join('')}
      </div>
    `;
    modalOverlay.classList.add('active');
  }

  window.closeModal = function() {
    modalOverlay.classList.remove('active');
  };

  // Setup Event Listeners
  function setupEventListeners() {
    // Grade Filter Pills (12, 11, 10)
    document.querySelectorAll('.grade-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.grade-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        state.currentGrade = parseInt(tab.getAttribute('data-grade'));
        state.selectedSubject = null;
        state.searchQuery = '';
        searchInput.value = '';
        renderMainView();
      });
    });

    // Back from Subject Books to Subject Grid
    btnBackToSubjects.addEventListener('click', () => {
      state.selectedSubject = null;
      renderMainView();
    });

    // Search Input
    searchInput.addEventListener('input', (e) => {
      state.searchQuery = e.target.value;
      state.selectedSubject = null;
      renderMainView();
    });

    searchClear.addEventListener('click', () => {
      searchInput.value = '';
      state.searchQuery = '';
      state.selectedSubject = null;
      renderMainView();
    });

    // Navigation Items
    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', () => {
        const view = item.getAttribute('data-view');
        switchView(view);
      });
    });

    // Header Actions
    document.getElementById('headerCartBtn').addEventListener('click', () => switchView('kart'));
    document.getElementById('headerNotifBtn').addEventListener('click', showNotificationsModal);

    // Modal Overlay Background Click
    modalOverlay.addEventListener('click', (e) => {
      if (e.target === modalOverlay) window.closeModal();
    });
  }

  // Initial App Startup
  setupEventListeners();
  updateCartBadge();
  renderMainView();

});
